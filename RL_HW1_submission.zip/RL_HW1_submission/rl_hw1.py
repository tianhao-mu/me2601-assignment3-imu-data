"""ME2502 Homework I：Gridworld 动态规划与两/三地点汽车租赁。

运行：python3 rl_hw1.py --output-dir results
依赖：Python 3.10+、NumPy。固定随机种子以便复现。
"""
from __future__ import annotations

import argparse
import csv
import itertools
import json
import math
from pathlib import Path

import numpy as np


def gridworld():
    """同步更新；终止阈值 1e-10；并列动作判断容差 1e-8。"""
    actions = ("U", "D", "L", "R")
    directions = ((0, 1), (0, -1), (-1, 0), (1, 0))
    terminals = {12, 6}  # 索引：(y-1)*4+x-1
    transition = np.zeros((16, 4), dtype=int)
    reward = np.full((16, 4), -1.0)
    for s in range(16):
        x, y = s % 4, s // 4
        for a, (dx, dy) in enumerate(directions):
            nx, ny = np.clip(x + dx, 0, 3), np.clip(y + dy, 0, 3)
            transition[s, a] = int(ny * 4 + nx)
        if s in terminals:
            transition[s, :] = s
            reward[s, :] = 0.0

    def q_values(v):
        return reward + v[transition]

    def greedy(v):
        q = q_values(v)
        mask = np.abs(q - q.max(axis=1, keepdims=True)) <= 1e-8
        return mask / mask.sum(axis=1, keepdims=True)

    v, pi = np.zeros(16), np.full((16, 4), 0.25)
    evaluation_sweeps = []
    policy_rounds = 0
    while True:
        count = 0
        while True:
            new = (pi * q_values(v)).sum(axis=1)
            count += 1
            delta = float(np.max(np.abs(new - v)))
            v = new
            if delta < 1e-10:
                break
        evaluation_sweeps.append(count)
        new_pi = greedy(v)
        policy_rounds += 1
        if np.array_equal(pi, new_pi):
            break
        pi = new_pi

    v_pi, final_pi = v.copy(), pi.copy()
    v = np.zeros(16)
    vi_sweeps = 0
    vi_changes = []
    while True:
        new = q_values(v).max(axis=1)
        vi_sweeps += 1
        delta = float(np.max(np.abs(new - v)))
        vi_changes.append(delta)
        v = new
        if delta < 1e-10:
            break
    expected = np.array([
        -min(abs(x - 1) + abs(y - 4), abs(x - 3) + abs(y - 2))
        for y in range(1, 5) for x in range(1, 5)
    ])
    assert np.allclose(v, expected, atol=1e-9)
    assert np.allclose(v_pi, expected, atol=1e-8)
    assert np.array_equal(greedy(v), final_pi)

    def display_policy(policy):
        return [["T" if (y * 4 + x) in terminals else "".join(
            actions[a] for a in range(4) if policy[y * 4 + x, a] > 0
        ) for x in range(4)] for y in reversed(range(4))]

    return {
        "values_top_to_bottom": v.reshape(4, 4)[::-1].tolist(),
        "policy_top_to_bottom": display_policy(final_pi),
        "pi_rounds_including_stability_check": policy_rounds,
        "pi_evaluation_sweeps": evaluation_sweeps,
        "pi_total_evaluation_sweeps": sum(evaluation_sweeps),
        "vi_sweeps_including_stability_check": vi_sweeps,
        "vi_max_changes": vi_changes,
    }


def poisson_pmf(rate, k):
    return math.exp(-rate) * rate**k / math.factorial(k)


def poisson_tail(rate, k):
    """P(X>=k)：精确聚合饱和需求和容量截断的尾部。"""
    if k <= 0:
        return 1.0
    return max(0.0, 1.0 - math.fsum(poisson_pmf(rate, j) for j in range(k)))


def location_model(rental_rate, return_rate, capacity=20):
    kernel = np.zeros((capacity + 1, capacity + 1))
    revenue = np.zeros(capacity + 1)
    for stock in range(capacity + 1):
        # fulfilled==stock 对应全部 demand>=stock；不是丢弃尾部。
        for fulfilled in range(stock + 1):
            prob = (poisson_pmf(rental_rate, fulfilled) if fulfilled < stock
                    else poisson_tail(rental_rate, stock))
            revenue[stock] += 10 * fulfilled * prob
            remaining = stock - fulfilled
            for end in range(remaining, capacity):
                kernel[stock, end] += prob * poisson_pmf(return_rate, end - remaining)
            kernel[stock, capacity] += prob * poisson_tail(return_rate, capacity - remaining)
    assert np.max(np.abs(kernel.sum(axis=1) - 1)) < 1e-12
    assert np.all(kernel >= 0)
    return kernel, revenue


def relocation_actions(n):
    """净流入向量；同价运输下无环最短运输的数量为 ||delta||_1/2。"""
    candidates = [d for d in itertools.product(range(-5, 6), repeat=n)
                  if sum(d) == 0 and sum(abs(x) for x in d) <= 10]
    return sorted(candidates, key=lambda d: (sum(abs(x) for x in d), d))


def solve_cars(rental_rates, return_rates, gamma=0.9, tolerance=1e-9):
    n = len(rental_rates)
    shape = (21,) * n
    models = [location_model(d, b) for d, b in zip(rental_rates, return_rates)]
    kernels = [m[0] for m in models]
    daily_revenue = np.zeros(shape)
    for axis, (_, revenue) in enumerate(models):
        dims = [1] * n
        dims[axis] = 21
        daily_revenue += revenue.reshape(dims)
    actions = relocation_actions(n)
    slices = []
    for d in actions:
        before = tuple(slice(max(0, -x), min(21, 21 - x)) for x in d)
        after = tuple(slice(max(0, x), min(21, 21 + x)) for x in d)
        slices.append((before, after, sum(abs(x) for x in d) / 2))

    def bellman(v):
        if n == 2:
            future = kernels[0] @ v @ kernels[1].T
        else:
            future = np.einsum("ia,jb,kc,abc->ijk", *kernels, v, optimize=True)
        post_value = daily_revenue + gamma * future
        best = np.full(shape, -np.inf)
        policy_index = np.zeros(shape, dtype=int)
        for index, (before, after, moved) in enumerate(slices):
            candidate = post_value[after] - 2 * moved
            improve = candidate > best[before] + 1e-12
            best[before] = np.maximum(best[before], candidate)
            policy_index[before] = np.where(improve, index, policy_index[before])
        return best, policy_index

    v = np.zeros(shape)
    sweeps = 0
    while True:
        new, _ = bellman(v)
        sweeps += 1
        change = float(np.max(np.abs(new - v)))
        v = new
        if change < tolerance:
            break
        if sweeps > 2000:
            raise RuntimeError("价值迭代未收敛")
    bellman_v, policy_index = bellman(v)
    residual = float(np.max(np.abs(bellman_v - v)))
    assert residual < tolerance
    policy = np.array(actions, dtype=int)[policy_index]
    states = np.moveaxis(np.indices(shape), 0, -1)
    assert np.all(policy.sum(axis=-1) == 0)
    assert np.all(np.abs(policy).sum(axis=-1) <= 10)
    assert np.all((states + policy >= 0) & (states + policy <= 20))
    return v, policy, {
        "rental_rates": list(rental_rates), "return_rates": list(return_rates),
        "num_states": 21**n, "max_num_actions": len(actions),
        "vi_sweeps": sweeps, "bellman_residual": residual,
        "value_error_bound": residual / (1 - gamma),
        "value_initial": float(v[(10,) * n]),
        "initial_relocation_delta": policy[(10,) * n].tolist(),
    }


def simulate_cars(policy, rental_rates, return_rates, days=60, seed=20261027):
    rng = np.random.default_rng(seed)
    n = len(rental_rates)
    state = np.full(n, 10, dtype=int)
    records = []
    for day in range(1, days + 1):
        delta = policy[tuple(state)] if policy is not None else np.zeros(n, dtype=int)
        after_move = state + delta
        assert delta.sum() == 0 and np.abs(delta).sum() <= 10
        assert np.all((after_move >= 0) & (after_move <= 20))
        demand = rng.poisson(rental_rates)
        returns = rng.poisson(return_rates)
        rentals = np.minimum(after_move, demand)
        # 先出租、再归还；当日归还不参与当日出租。
        raw_end = after_move - rentals + returns
        end = np.minimum(20, raw_end)
        moved = int(np.abs(delta).sum() // 2)
        reward = int(10 * rentals.sum() - 2 * moved)
        records.append({"day": day, "state": state.tolist(), "delta": delta.tolist(),
                        "after_move": after_move.tolist(), "demand": demand.tolist(),
                        "rentals": rentals.tolist(), "returns": returns.tolist(),
                        "removed": (raw_end - end).tolist(), "next_state": end.tolist(),
                        "moved": moved, "reward": reward})
        state = end
    return records


def save_simulation(path, records):
    with path.open("w", newline="", encoding="utf-8-sig") as stream:
        writer = csv.DictWriter(stream, fieldnames=records[0].keys())
        writer.writeheader()
        writer.writerows(records)


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--output-dir", type=Path, default=Path("results"))
    args = parser.parse_args()
    args.output_dir.mkdir(parents=True, exist_ok=True)
    results = {"gridworld": gridworld(), "seed": 20261027, "simulation_days": 60}
    for n, demand, returns in [(2, (3, 4), (3, 2)), (3, (3, 4, 2), (3, 2, 4))]:
        v, policy, info = solve_cars(demand, returns)
        records = simulate_cars(policy, demand, returns)
        baseline = simulate_cars(None, demand, returns)
        np.save(args.output_dir / f"cars_{n}_values.npy", v)
        np.save(args.output_dir / f"cars_{n}_policy.npy", policy)
        save_simulation(args.output_dir / f"cars_{n}_simulation.csv", records)
        save_simulation(args.output_dir / f"cars_{n}_baseline.csv", baseline)
        info.update({"first_10_days": records[:10],
                     "simulation_total_reward": sum(r["reward"] for r in records),
                     "baseline_total_reward": sum(r["reward"] for r in baseline),
                     "simulation_total_moved": sum(r["moved"] for r in records)})
        if n == 2:
            # 表格按 n1 从20到0逐行、n2 从0到20逐列；正 a 表示1->2。
            np.savetxt(args.output_dir / "cars_2_transfer_policy.csv", -policy[::-1, :, 0],
                       fmt="%d", delimiter=",")
        results[f"cars_{n}"] = info
    (args.output_dir / "results.json").write_text(
        json.dumps(results, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    grid = results["gridworld"]
    for name in ("策略迭代", "价值迭代"):
        print(f"\nQuestion 3 — {name}：最优价值（y=4到1，x=1到4）")
        for row in grid["values_top_to_bottom"]:
            print(" ".join(f"{value:6.1f}" for value in row))
        print("最优策略（列出全部并列动作）")
        for row in grid["policy_top_to_bottom"]:
            print(" ".join(f"{action:^6}" for action in row))
    print(f"PI外层轮数：{grid['pi_rounds_including_stability_check']}；"
          f"PI评估扫描：{grid['pi_evaluation_sweeps']}；"
          f"VI扫描：{grid['vi_sweeps_including_stability_check']}")
    print(json.dumps(results, ensure_ascii=False, indent=2))
    print("验证通过：转移概率、Gridworld 最优解、并列动作、调车约束、Bellman 残差。")


if __name__ == "__main__":
    main()
