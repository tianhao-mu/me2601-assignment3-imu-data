ME2502 Reinforcement Learning — Homework I

完整英文报告：RL_HW1_solution.pdf
LaTeX 源码：latex/main.tex
计算与仿真程序：rl_hw1.py

运行（Python 3.11+；程序语法支持 3.10+，NumPy 2.3.5 要求 3.11+）：
  python3 -m pip install -r requirements.txt
  python3 rl_hw1.py --output-dir results

也可使用已有兼容版本的 NumPy，程序不依赖 SciPy。
本次结果使用 NumPy 2.3.5；随机种子 20261027；两/三地点分别仿真 60 天。

Question 3：同步策略迭代与价值迭代；评估阈值 1e-10，并列容差 1e-8。
策略迭代外层3轮，其中2轮改变策略，评估扫描259+4+1=264次；价值迭代4次扫描。
最后一次均计入确认收敛的检查。网格输出从上到下为y=4,3,2,1。

Question 4：两地点与三地点均计算完整价值迭代策略，折扣0.9，阈值1e-9。
租车均值：(3,4) / (3,4,2)；归还均值：(3,2) / (3,2,4)。
返回数据与策略数组以库存本身为索引，数组不翻转。
policy.npy 的最后一轴是各地点净调入量；所有分量和为0。
仅 cars_2_transfer_policy.csv 使用标量动作a（正数表示1向2调车），
其行从n1=20递减到0、列从n2=0递增到20；该CSV没有表头。

results目录：
  results.json                 全部摘要、网格结果和仿真前10天
  cars_2/3_values.npy           完整价值数组（文件名实际为cars_2_values.npy等）
  cars_2/3_policy.npy           完整净调入策略数组
  cars_2/3_simulation.csv       60天逐日仿真记录
  cars_2/3_baseline.csv         相同随机样本、不调车的基线记录
  cars_2_transfer_policy.csv    两地点可读策略矩阵

仿真先调车、再出租、最后归还并裁剪容量；归还不参与当天出租。
泊松分布的尾部按饱和需求与容量事件精确合并，没有任意丢弃尾部。
仿真累计收入是未折扣的单样本路径，不能与无限时域折扣价值直接比较。

LaTeX编译（需pdfLaTeX和常用TeX Live宏包）：
  cd latex
  pdflatex -interaction=nonstopmode -halt-on-error main.tex
  pdflatex -interaction=nonstopmode -halt-on-error main.tex
